#Setting the working directory
setwd("C:\\Users\\IT24102444\\Desktop\\IT24102444")

##Exercise
##01)Import the dataset (’Exercise.txt’) and re-naming it
data<-read.table("Exercise.txt", header=TRUE, sep = " ")
##View the dataset
fix(data)

#Renaming dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = "\t")
##View the dataset
fix(data)

#02
str(branch_data)
str(data)

#03
#Obtain boxplot for sales and interpret the shape of the sales distribution.
boxplot(sales_X1="Box plot for Sales", outline=TRUE, outpch=8,horizontal=TRUE)

#04
#five number summary and IQR for advertising variable
#five number summary
quantile(Advertising_X2)
#IQR
IQR(Advertising_X2)

#05
#find the outliers in a numeric vector and check for outliers in years variables.
#Function to get outliner
get.outlier<-function(z){
  q1 <- quantile(z)[2]
  q2 <- quantile(z)[4]
  iqr <- q3 - q1
  
  #ub = upper boundry
  ub <- q3 + 1.5*iqr
  #lb = lower boundry
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Ourliers: ", paste(sort(z[z<lb | z>ub]), collapse = ",")))
}

get.outliers(Sales_X1)
get.outliers(Years_X3)
