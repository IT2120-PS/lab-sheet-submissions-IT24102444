#Setting the working directory
setwd("C:\\Users\\dampa\\OneDrive\\Desktop\\IT24102444")

##Exercise
##01)Import the dataset (’Exercise1.txt’) and re-naming it
data<-read.table("Exercise1.txt", header=TRUE, sep = " ")
##View the dataset
fix(data)

#Renaming dataset
branch_data <- read.table("Exercise1.txt", header = TRUE, sep = " ")
##View the dataset
fix(branch_data)

#02
str(branch_data)

head(branch_data$Sales_X1)

#03
dev.new(width=10, height=6)  # Opens a new window (in inches)
#Obtain boxplot for sales and interpret the shape of the sales distribution.
boxplot(branch_data$Sales_X1, main ="Box plot for Sales", outline=TRUE, outpch=8,horizontal=TRUE)

#04
#five number summary and IQR for advertising variable
#five number summary
quantile(branch_data$Advertising_X2)
#IQR
IQR(branch_data$Advertising_X2)

#05
#find the outliers in a numeric vector and check for outliers in years variables.
#Function to get outliner
get.outlier<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  #ub = upper boundry
  ub <- q3 + 1.5*iqr
  #lb = lower boundry
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  outlier = paste(sort(z[z<lb | z>ub]))
  
  if (length(outlier) == 0) {
    print("No outliers")
  } else {
    print(outlier)
  }
}

get.outlier(branch_data$Sales_X1)
get.outlier(branch_data$Years_X3)

