#Lab sheet 04
#Setting the working directory
setwd("C:\\Users\\IT24102444\\Desktop\\IT24102444")

##Part 1
##Importing the dataset(data4)
data<-read.table("DATA 4.txt", header=TRUE, sep = "")

##View the file
fix(data)

#attaching the file to R
#So that can call variables by their name
attach(data)


#Part 2
#(a)
#Box-plot
boxplot(X1, main = "Box plot for Team Attendance", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X2, main = "Box plot for Team Salary", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X3, main = "Box plot for Years", outline = TRUE, outpch = 8, horizontal = TRUE)

#Histogram
hist(X1, ylab = "Frequency", xlab = "Team Attendance", main = "Histogram for Team Attendance")
hist(X2, ylab = "Frequency", xlab = "Team Salary", main = "Histogram for Team Salary")
hist(X3, ylab = "Frequency", xlab = "Years", main = "Histogram for Years")

#Stem and leaf plot
stem(X1)
stem(X2)
stem(X3)

#(b)
#Mean
mean(x1)
