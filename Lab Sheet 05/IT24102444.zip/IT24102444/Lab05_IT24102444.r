#Exercise

#Setting directory
setwd("C:\\Users\\IT24102444\\Desktop\\IT24102444")

#Q1
#Import dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
fix(Delivery_Times)

#renaming the variables
names(Delivery_Times) <- c("X1")
attach(Delivery_Times)

fix(Delivery_Times)

#Q2
#Drawing a histogram
histogram <- hist(X1, main = "Histrogram for Delivery Time ", breaks = seq(20,70,length = 9), right = FALSE)

#Q3
#Shape of the distribution => Positively Skewed Distribution

#Q4
#Cumulative frequency polygon (ogive) for the data in a separate plot

#Constructing frequency distribution
#assigning class limits
breaks <- round(histogram$breaks)
#assign class frequencies of hist into variable(freq)
freq <- histogram$counts
#assign mid point of each class
mids <- histogram$mids

#creating a variable(classes)
classes <- c()

#assign classes 
for(i in 1:length(breaks)-1){
  classes[i] <- paste0("(", breaks[i], ", ", breaks[i+1], ")")
}

#obtaining freq distribution by combining the values of "Classes" & "freq" variables
#cbind command => to merge columns with same length
cbind(classes= classes, Frequency=freq)

#Portray the distribution in a cumulative frequency polygon (ogive)
cum.freq <- cumsum(freq)

##Creating a new variable
new <- c()

##Storing cumulative frequencies in order to get ogive
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i] = cum.freq[i-1]
  }
}

##plotting the polygon
plot(breaks, new, type = 'l', main = "Cumalative Frequency Polygon", xlab = "Delivery Time", ylab = "Cumulative Frequency", ylim = c(0,max(cum.freq)) )
