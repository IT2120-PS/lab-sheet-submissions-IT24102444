#Lab 08
setwd("C:\\Users\\IT24102444\\Desktop\\IT24102444_Lab08")

#importing the dataset
data1<- read.table("Data - Lab 8.txt", header = TRUE)
fix(data)
attach(data1)

#The nicotine contents, in milligrams for 40 cigarettes of a certain brand (population) were recorded.

#Q1
#mean
popmn<- mean(Nicotine)
#Variance
popvar<-var(Nicotine)

#Q2
#30 random samples of size 5

#creating null sample dataset
samples<-c()
n<-c()

for(i in 1:30){
  s<-sample(Nicotine,5,replace = TRUE)
  samples<-cbind(samples, s)
  n<-c(n,paste('s',i))
}

colnames(samples)=n

#apply --> calculate mean,variance, etc row wise or coulmn wise matrics
s.mean<-apply(samples,2,mean)
s.vars<-apply(samples, 2, var)

#Q3
sampleMean<-mean(s.mean)
sampleVars<-var(s.mean)

#Q4
popmn
sampleMean

#Q5
popvar/5
sampleVars





