#Exercise

setwd("C:\\Users\\IT24102444\\Desktop\\IT24102444_Lab08")

data<-read.table("Exercise - LaptopsWeights.txt", header=TRUE)
fix(data)
attach(data)

#Q1
popmn<-mean(Weight.kg.)
popvar<-sd(Weight.kg.)

#Q2
#25 random samples of size 6

#Creating a null sample space
samples<-c()
n<-c()

#assigning values having size 6
for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(sample,s)
  n<-c(n,paste('s',i))
}

s.mean<-apply(samples,2,mean)
s.sd<-apply(samples, 2, sd)


#Q3










