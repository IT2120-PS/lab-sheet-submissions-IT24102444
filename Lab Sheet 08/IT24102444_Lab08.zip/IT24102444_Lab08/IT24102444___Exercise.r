#Exercise

setwd("C:\\Users\\dampa\\OneDrive\\Desktop\\IT24102444_Lab08")

data<-read.table("Exercise - LaptopsWeights.txt", header=TRUE)
fix(data)
attach(data)

#Q1
popmn<-mean(Weight.kg.)
popsd<-sd(Weight.kg.)

#Q2
#25 random samples of size 6

#Creating a null sample space
samples<-c()
n<-c()

#assigning values having size 6
samples <- NULL   
n <- NULL         

for(i in 1:25){
  s <- sample(Weight.kg., 6, replace = TRUE)  
  samples <- cbind(samples, s)                
  n <- c(n, paste('s', i))                    
}

colnames(samples) <- n

# mean and sd
s_mean <- apply(samples, 2, mean)
s_sd   <- apply(samples, 2, sd)

#Q3
mean_of_sample_means <- mean(s_mean)
sd_of_sample_means   <- sd(s_mean)

cat("Mean of sample means =", mean_of_sample_means,"\n")
cat("True mean = ",popmn, "\n" )

cat("SD of sample means =", sd_of_sample_means,"\n")
cat("True standard deviation = ",popsd)

#Relationship

#The mean of the sample means is approximately equal to the true population mean.

#The standard deviation of the sample means (0.0783) is smaller than the population standard deviation (0.2561). 
#This is because sample means are less variable than individual values. 







